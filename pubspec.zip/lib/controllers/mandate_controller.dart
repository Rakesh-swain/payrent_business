import 'dart:convert';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:payrent_business/widgets/dialog.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/mandate_model.dart';
import '../services/firestore_service.dart';
import '../controllers/auth_controller.dart';

class MandateController extends GetxController {
  final FirestoreService _firestoreService = Get.find<FirestoreService>();
  final AuthController _authController = Get.find<AuthController>();

  // API endpoints
  // https://sandbox-payrent.paycorp.io
  static const String _baseUrl = 'https://sandbox-payrent.paycorp.io';
  static const String _mandateDetailsEndpoint = '/mandate/create';
  static const String _mandateEnquiryEndpoint = '/mandate/enquiry';
  static const String _mandateAmendment = '/mandate/amendment';
  static const String _mandateTermination = '/mandate/termination';
  static const String _mandatePaymentList = '/mandate/enquiry/payment-list';


  // Observable lists
  final RxList<MandateModel> _mandates = <MandateModel>[].obs;
  final RxBool _isLoading = false.obs;
  final RxString _errorMessage = ''.obs;

  // Getters
  List<MandateModel> get mandates => _mandates;
  bool get isLoading => _isLoading.value;
  String get errorMessage => _errorMessage.value;
  int get mandateCount => _mandates.length;

  @override
  void onInit() {
    super.onInit();
    fetchMandates();
  }

  /// Fetch all mandates for current user from Firestore
  Future<void> fetchMandates() async {
    try {
      _isLoading.value = true;
      _errorMessage.value = '';

      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      final querySnapshot = await _firestoreService.querySubcollectionDocuments(
        parentCollection: 'users',
        parentDocumentId: currentUser.uid,
        subcollection: 'mandates',
        orderBy: 'createdAt',
        descending: true,
      );

      final mandateList = querySnapshot.docs
          .map((doc) => MandateModel.fromFirestore(doc))
          .toList();

      _mandates.assignAll(mandateList);
    } catch (e) {
      _errorMessage.value = 'Error fetching mandates: $e';
      print('Error fetching mandates: $e');
    } finally {
      _isLoading.value = false;
    }
  }

  /// Calculate end date based on start date, number of installments and frequency
  DateTime calculateEndDate(
    DateTime startDate,
    int noOfInstallments,
    String frequency,
  ) {
    switch (frequency.toLowerCase()) {
      case 'daily':
        return startDate.add(Duration(days: noOfInstallments - 1));
      case 'weekly':
        return startDate.add(Duration(days: (noOfInstallments - 1) * 7));
      case 'monthly':
        // Add months (approximate, actual month lengths may vary)
        return DateTime(
          startDate.year,
          startDate.month + (noOfInstallments - 1),
          startDate.day,
        );
      case 'yearly':
        return DateTime(
          startDate.year + (noOfInstallments - 1),
          startDate.month,
          startDate.day,
        );
      default:
        // Default to weekly
        return startDate.add(Duration(days: (noOfInstallments - 1) * 7));
    }
  }

  /// Generate a unique reference number (UUID v4, 32 characters)
  String generateReferenceNumber() {
    const uuid = Uuid();
    return uuid.v4().replaceAll('-', ''); // Remove dashes to get 32 characters
  }

  String generateCustomId({int randomLength = 16}) {
    const fixedPart = 'BSOHOPBMNDPC';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rnd = Random();

    final randomPart = List.generate(
      randomLength,
      (_) => chars[rnd.nextInt(chars.length)],
    ).join();

    return fixedPart + randomPart;
  }

  /// Create a new mandate (call API and save to Firestore)
  Future<MandateModel?> createMandate({
    required String landlordId,
    required String tenantId,
    required String propertyId,
    required String unitId,
    required String landlordAccountHolderName,
    required String landlordAccountNumber,
    required String landlordIdType,
    required String landlordIdNumber,
    required String landlordBankBic,
    required String landlordBranchCode,
    required String tenantAccountHolderName,
    required String tenantAccountNumber,
    required String tenantIdType,
    required String tenantIdNumber,
    required String tenantBankBic,
    required String tenantBranchCode,
    required int rentAmount,
    required DateTime startDate,
    required int noOfInstallments,
    required String paymentFrequency,
    required BuildContext context,
  }) async {
    try {
      _isLoading.value = true;
      _errorMessage.value = '';

      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Generate reference number and calculate end date
      final referenceNumber = generateReferenceNumber();
      final endDate = calculateEndDate(
        startDate,
        noOfInstallments,
        paymentFrequency,
      );

      // Create mandate model
      final mandate = MandateModel(
        landlordId: landlordId,
        tenantId: tenantId,
        propertyId: propertyId,
        unitId: unitId,
        referenceNumber: referenceNumber,
        landlordAccountHolderName: 'RIVER Solution LLC', //landlordAccountHolderName,
        landlordAccountNumber: '043020070434', //landlordAccountNumber,
        landlordIdType: landlordIdType,
        landlordIdNumber: landlordIdNumber,
        landlordBankBic: 'BSHROMRU',//landlordBankBic,
        landlordBranchCode: landlordBranchCode,
        tenantAccountHolderName: "Dsm Adhhtha Saosin",//tenantAccountHolderName,
        tenantAccountNumber: '002010427738', //tenantAccountNumber,
        tenantIdType: tenantIdType,
        tenantIdNumber: tenantIdNumber,
        tenantBankBic: 'BSHROMRU',//tenantBankBic,
        tenantBranchCode: tenantBranchCode,
        rentAmount: rentAmount,
        paymentFrequency: paymentFrequency,
        startDate: startDate,
        endDate: endDate,
        noOfInstallments: noOfInstallments,
        status: 'pending',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      // Call API to create mandate
      final apiResponse = await _callMandateDetailsApi(mandate);

      if (apiResponse != null && apiResponse['MMSStatus'] != null) {
        // Update mandate with API response data
        final updatedMandate = mandate.copyWith(
          mmsId: apiResponse["MMSId"],
          mmsStatus: 'pending',
          status: 'pending',
        );

        // Save to Firestore
        final docRef = await _firestoreService.createSubcollectionDocument(
          parentCollection: 'users',
          parentDocumentId: currentUser.uid,
          subcollection: 'mandates',
          data: updatedMandate.toFirestore(),
        );

        // // Add to local list
        // final finalMandate = updatedMandate.copyWith();
        // _mandates.insert(0, finalMandate);
        await fetchMandates();

        if (mandate != null) {  
          Navigator.pop(context);
          CustomDialogs.showSuccessDialog(context);
        }

        return updatedMandate;
      } else {
        CustomDialogs.showErrorDialog(
          context,
          '${apiResponse != null ? apiResponse['errorMessage'] : 'Unknown error'}',
        );
      }
    } catch (e) {
      _errorMessage.value = 'Error creating mandate: $e';
      Get.snackbar(
        'Error',
        'Failed to create mandate: $e',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.9),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        borderRadius: 8,
      );

      print('Error creating mandate: $e');
      return null;
    } finally {
      _isLoading.value = false;
    }
  }
  //   Future<MandateModel?> createMandate({
  //   required String landlordId,
  //   required String tenantId,
  //   required String propertyId,
  //   required String unitId,
  //   required String landlordAccountHolderName,
  //   required String landlordAccountNumber,
  //   required String landlordIdType,
  //   required String landlordIdNumber,
  //   required String landlordBankBic,
  //   required String landlordBranchCode,
  //   required String tenantAccountHolderName,
  //   required String tenantAccountNumber,
  //   required String tenantIdType,
  //   required String tenantIdNumber,
  //   required String tenantBankBic,
  //   required String tenantBranchCode,
  //   required int rentAmount,
  //   required DateTime startDate,
  //   required int noOfInstallments,
  //   required String paymentFrequency,
  //   required BuildContext context,
  // }) async {
  //   try {
  //     _isLoading.value = true;
  //     _errorMessage.value = '';

  //     final currentUser = FirebaseAuth.instance.currentUser;
  //     if (currentUser == null) {
  //       throw Exception('User not authenticated');
  //     }

  //     // Generate reference number and calculate end date
  //     final referenceNumber = generateReferenceNumber();
  //     final endDate = calculateEndDate(
  //       startDate,
  //       noOfInstallments,
  //       paymentFrequency,
  //     );

  //     // Create mandate model
  //     final mandate = MandateModel(
  //       landlordId: landlordId,
  //       tenantId: tenantId,
  //       propertyId: propertyId,
  //       unitId: unitId,
  //       referenceNumber: referenceNumber,
  //       landlordAccountHolderName: landlordAccountHolderName,
  //       landlordAccountNumber: '020020011206', // replace later
  //       landlordIdType: landlordIdType,
  //       landlordIdNumber: landlordIdNumber,
  //       landlordBankBic: landlordBankBic,
  //       landlordBranchCode: landlordBranchCode,
  //       tenantAccountHolderName: tenantAccountHolderName,
  //       tenantAccountNumber: '001020032647', // replace later
  //       tenantIdType: tenantIdType,
  //       tenantIdNumber: tenantIdNumber,
  //       tenantBankBic: tenantBankBic,
  //       tenantBranchCode: tenantBranchCode,
  //       rentAmount: rentAmount,
  //       paymentFrequency: paymentFrequency,
  //       startDate: startDate,
  //       endDate: endDate,
  //       noOfInstallments: noOfInstallments,
  //       status: 'pending',
  //       createdAt: DateTime.now(),
  //       updatedAt: DateTime.now(),
  //     );

  //     // Generate a custom MMS ID (temporary)
  //     String mmsId = generateCustomId();
  //     final updatedMandate = mandate.copyWith(
  //       mmsId: mmsId,
  //       mmsStatus: 'pending',
  //       status: 'pending',
  //     );

  //     // Save to Firestore
  //     final docRef = await _firestoreService.createSubcollectionDocument(
  //       parentCollection: 'users',
  //       parentDocumentId: currentUser.uid,
  //       subcollection: 'mandates',
  //       data: updatedMandate.toFirestore(),
  //     );

  //     // Refresh mandates list
  //     await fetchMandates();

  //     // ✅ Always create payment schedule immediately after creating mandate
  //     await createPaymentSchedule(
  //       landlordId: currentUser.uid,
  //       mandateId: docRef.id, // Firestore document ID
  //       tenantId: tenantId,
  //       propertyId: propertyId,
  //       unitId: unitId,
  //       refNumber: referenceNumber,
  //       mmsId: mmsId,
  //       frequency: paymentFrequency,
  //       amount: rentAmount,
  //       startDate: startDate,
  //       numberOfPayments: noOfInstallments,
  //     );

  //     // Success dialog
  //     Get.back();
  //     CustomDialogs.showSuccessDialog(context);

  //     return updatedMandate;
  //   } catch (e) {
  //     _errorMessage.value = 'Error creating mandate: $e';
  //     Get.snackbar(
  //       'Error',
  //       'Failed to create mandate: $e',
  //       snackPosition: SnackPosition.BOTTOM,
  //       backgroundColor: Colors.red.withOpacity(0.9),
  //       colorText: Colors.white,
  //       margin: const EdgeInsets.all(12),
  //       borderRadius: 8,
  //     );
  //     print('Error creating mandate: $e');
  //     return null;
  //   } finally {
  //     _isLoading.value = false;
  //   }
  // }

  /// Call the mandate details API
  Future<Map<String, dynamic>?> _callMandateDetailsApi(
    MandateModel mandate,
  ) async {
    try {
      final url = Uri.parse('$_baseUrl$_mandateDetailsEndpoint');
      final payload = mandate.toApiPayload();

      print('Calling mandate details API: $url');
      print('Payload: $payload');

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      print('API Response Status: ${response.statusCode}');
      print('API Response Body: ${response.body}');

      if (response.statusCode == 202) {
        final responseData = jsonDecode(response.body);
        print(responseData);
        return responseData;
      } else {
        throw Exception('API call failed with status: ${response.statusCode}');
      }
    } catch (e) {
      print('Error calling mandate details API: $e');
      return null;
    }
  }

  /// Update mandate status by calling the enquiry API
  Future<bool> updateMandateStatus(
    String mandateId,
    String tenantId,
    String propertyId,
    String unitId,
    String refNumber,
    String mmsId,
    String frequency,
    int amount,
    DateTime startDate,
    int noOfInstallments,
  ) async {
    try {
      _isLoading.value = true;
      _errorMessage.value = '';

      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Find the mandate
      final mandate = _mandates.firstWhere(
        (m) => m.id == mandateId,
        orElse: () => throw Exception('Mandate not found'),
      );

      if (mandate.mmsId == null) {
        throw Exception('MMS ID not available');
      }

      // Call enquiry API
      final apiResponse = await _callMandateEnquiryApi(mandate.mmsId!);
      print(apiResponse);
      if (apiResponse != null) {
        final newStatus = apiResponse['MMSStatus'] ?? mandate.mmsStatus;

        // Update in Firestore
        await _firestoreService.updateSubcollectionDocument(
          parentCollection: 'users',
          parentDocumentId: currentUser.uid,
          subcollection: 'mandates',
          documentId: mandateId,
          data: {
            'mmsStatus': newStatus,
            'updatedAt': DateTime.now(),
            'status': newStatus,
          },
        );

        // Update local list
        final index = _mandates.indexWhere((m) => m.id == mandateId);
        if (index != -1) {
          _mandates[index] = mandate.copyWith(
            mmsStatus: newStatus,
            status: newStatus,
          );
        }
        if (newStatus.toString().toLowerCase() == "accepted") {
          await createPaymentSchedule(
            landlordId: currentUser.uid,
            mandateId: mandateId,
            tenantId: tenantId,
            propertyId: propertyId,
            unitId: unitId,
            refNumber: refNumber,
            mmsId: mmsId,
            frequency: frequency,
            amount: amount,
            startDate: startDate,
            numberOfPayments: noOfInstallments,
          );
        }

        return true;
      } else {
        throw Exception('Failed to get mandate status from API');
      }
    } catch (e) {
      _errorMessage.value = 'Error updating mandate status: $e';
      Get.snackbar(
        'Error',
        'Failed to update mandate status: $e',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.9),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        borderRadius: 8,
      );
      print('Error updating mandate status: $e');
      return false;
    } finally {
      _isLoading.value = false;
    }
  }

  /// Call the mandate enquiry API
  Future<Map<String, dynamic>?> _callMandateApi(
  String endpoint,
  Map<String, dynamic> payload,
) async {
  try {
    final url = Uri.parse('$_baseUrl$endpoint');

    print('Calling API: $url');
    print('Payload: $payload');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );

    print('API Response Status: ${response.statusCode}');
    print('API Response Body: ${response.body}');

    if (response.statusCode == 202) {
      final data = jsonDecode(response.body);
      print(data);
      return data;
    } else {
      throw Exception('API failed with status: ${response.statusCode}');
    }
  } catch (e) {
    print('Error calling API: $e');
    return null;
  }
}

  Future<Map<String, dynamic>?> _callMandateEnquiryApi(String mmsId) {
  return _callMandateApi(_mandateEnquiryEndpoint, {'mmsId': mmsId});
}
Future<Map<String, dynamic>?> callMandateAmendment(String mmsId) {
  return _callMandateApi(_mandateAmendment, {'mmsId': mmsId});
}
Future<Map<String, dynamic>?> callMandateTermination(String mmsId) {
  return _callMandateApi(_mandateTermination, {'mmsId': mmsId});
}


  Future<void> createPaymentSchedule({
    required String landlordId,
    required String mandateId,
    required String tenantId,
    required String propertyId,
    required String unitId,
    required String mmsId,
    required String refNumber, // Mandate-level reference
    required String frequency, // monthly, quarterly, half-yearly, yearly
    required int amount,
    required DateTime startDate,
    required int numberOfPayments,
  }) async {
    final paymentsRef = FirebaseFirestore.instance
        .collection('users')
        .doc(landlordId)
        .collection('payments');

    int monthInterval = switch (frequency.toLowerCase()) {
      'monthly' => 1,
      'quarterly' => 3,
      'half-yearly' => 6,
      'yearly' => 12,
      _ => throw Exception('Invalid frequency type'),
    };

    for (int i = 0; i < numberOfPayments; i++) {
      final dueDate = DateTime(
        startDate.year,
        startDate.month + (i * monthInterval),
        startDate.day,
      );

      // Create doc reference so we can use its ID
      final docRef = paymentsRef.doc();

      await docRef.set({
        'payment_ref_number': docRef.id, // 👈 unique payment reference (doc ID)
        'schedule_number': i + 1, // 👈 schedule number (1-based)
        'mandate_id': mandateId,
        'tenant_id': tenantId,
        'landlord_id': landlordId,
        'property_id': propertyId,
        'unit_id': unitId,
        'mmsId': mmsId,
        'ref_number': refNumber, // Mandate-level reference
        'frequency': frequency,
        'amount': amount,
        'status': 'pending', // pending | paid | overdue
        'due_date': Timestamp.fromDate(dueDate),
        'payment_date': null,
        'created_at': Timestamp.now(),
      });
    }
  }

  /// Get mandate by ID
  MandateModel? getMandateById(String id) {
    try {
      return _mandates.firstWhere((mandate) => mandate.id == id);
    } catch (e) {
      return null;
    }
  }

  /// Get mandates by status
  List<MandateModel> getMandatesByStatus(String status) {
    return _mandates.where((mandate) => mandate.mmsStatus == status).toList();
  }

  /// Get active mandates
  List<MandateModel> getActiveMandates() {
    return _mandates
        .where((mandate) => mandate.mmsStatus!.toLowerCase() == 'accepted')
        .toList();
  }

  /// Get pending mandates
  List<MandateModel> getPendingMandates() {
    return _mandates
        .where((mandate) => mandate.mmsStatus!.toLowerCase() == 'pending')
        .toList();
  }

  /// Clear error message
  void clearError() {
    _errorMessage.value = '';
  }

  /// Refresh mandates
  Future<void> refreshMandates() async {
    await fetchMandates();
  }
}
